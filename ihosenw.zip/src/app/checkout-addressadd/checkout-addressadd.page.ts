import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout-addressadd',
  templateUrl: './checkout-addressadd.page.html',
  styleUrls: ['./checkout-addressadd.page.scss'],
})
export class CheckoutAddressaddPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
