import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout-online',
  templateUrl: './checkout-online.page.html',
  styleUrls: ['./checkout-online.page.scss'],
})
export class CheckoutOnlinePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
