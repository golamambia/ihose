import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout-addressedit',
  templateUrl: './checkout-addressedit.page.html',
  styleUrls: ['./checkout-addressedit.page.scss'],
})
export class CheckoutAddresseditPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
